package com.example.hotanbeadando;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class MainActivity extends AppCompatActivity {

    EditText etMass, etSpecificHeat, etDeltaT;

    EditText etWork, etInputHeat;

    TextView tvHeatResult, tvEfficiencyResult;

    Button btnHeat, btnEfficiency;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etMass = findViewById(R.id.etMass);
        etSpecificHeat = findViewById(R.id.etSpecificHeat);
        etDeltaT = findViewById(R.id.etDeltaT);

        etWork = findViewById(R.id.etWork);
        etInputHeat = findViewById(R.id.etInputHeat);

        tvHeatResult = findViewById(R.id.tvHeatResult);
        tvEfficiencyResult = findViewById(R.id.tvEfficiencyResult);

        btnHeat = findViewById(R.id.btnHeat);
        btnEfficiency = findViewById(R.id.btnEfficiency);

        btnHeat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double m = Double.parseDouble(etMass.getText().toString());
                double c = Double.parseDouble(etSpecificHeat.getText().toString());
                double dT = Double.parseDouble(etDeltaT.getText().toString());

                double Q = m * c * dT;
                tvHeatResult.setText("Hőmennyiség: " + Q + " J");
            }
        });

        btnEfficiency.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double W = Double.parseDouble(etWork.getText().toString());
                double Q = Double.parseDouble(etInputHeat.getText().toString());

                double eta = (W / Q) * 100;
                tvEfficiencyResult.setText("Hatásfok: " + eta + " %");
            }
        });
    }
}
